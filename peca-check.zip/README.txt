PEÇA CHECK — versão inicial funcional
======================================

Arquivo principal: index.html

Como testar:
1. Abra o index.html em um navegador.
2. Na tela inicial, digite M68444.
3. Toque em CONSULTAR.
4. Explore ICFS, Fotos da peça, Desenho 3D, Informações Pintura,
   Fluxo de produção e Dispositivos de elevação.

Observação:
Esta é uma versão protótipo offline. Os dados de M68444 são exemplos
para demonstrar o funcionamento. O próximo passo é conectar as telas
a um banco de dados real e às pastas/arquivos reais das peças.
